﻿using System;

namespace Deta.addons
{
    class test : Form1.addon
    {
        public string get(string input)
        {
            return input;
        }
    }
}
